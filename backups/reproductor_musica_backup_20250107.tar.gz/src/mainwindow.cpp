#include "mainwindow.h"
#include <QStyle>
#include <QGroupBox>
#include <QFileInfo>
#include <QMediaMetaData>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , reproductor(new Reproductor(this))
{
    crearWidgets();
    crearLayout();
    crearConexiones();
    configurarBarraEstado();
    
    // Configurar ventana
    setMinimumSize(800, 600);
    setWindowTitle("Reproductor de Música");
    
    // Aplicar tema inicial
    aplicarTema(Tema::AppleMusic);
}

void MainWindow::crearWidgets() {
    // Botones principales
    botonAbrir = new QPushButton("Abrir Archivo", this);
    botonAbrir->setObjectName("botonAbrir");
    
    // Botones de control
    botonReproducir = new QPushButton(this);
    botonPausar = new QPushButton(this);
    
    // Configurar iconos
    QIcon iconoPlay(":/resources/icons/play.svg");
    QIcon iconoPause(":/resources/icons/pause.svg");
    botonReproducir->setIcon(iconoPlay);
    botonPausar->setIcon(iconoPause);
    
    // Configurar tamaño de iconos
    botonReproducir->setIconSize(QSize(32, 32));
    botonPausar->setIconSize(QSize(32, 32));
    
    // Configurar tooltips
    botonReproducir->setToolTip("Reproducir");
    botonPausar->setToolTip("Pausar");
    
    // Sliders
    sliderProgreso = new QSlider(Qt::Horizontal, this);
    sliderVolumen = new QSlider(Qt::Horizontal, this);
    sliderVolumen->setMaximum(100);
    sliderVolumen->setValue(100);
    sliderVolumen->setMaximumWidth(100);
    
    // Etiquetas
    etiquetaVolumen = new QLabel("Volumen: 100%", this);
    etiquetaTitulo = new QLabel("Sin título", this);
    etiquetaArtista = new QLabel("Sin artista", this);
    etiquetaAlbum = new QLabel("Sin álbum", this);
    etiquetaGenero = new QLabel("Sin género", this);
    etiquetaCalidad = new QLabel("Calidad: -", this);
    
    etiquetaSampleRate = new QLabel("Sample rate: -");
    etiquetaChannels = new QLabel("Canales: -");
    etiquetaBitrate = new QLabel("Bitrate: -");
    etiquetaCodec = new QLabel("Codec: -");
    etiquetaCodecProfile = new QLabel("Perfil: -");
    etiquetaEncoding = new QLabel("Codificación: -");
    etiquetaTagType = new QLabel("Tipo de etiqueta: -");
    
    // Configurar fuentes y estilos
    QFont tituloFont = etiquetaTitulo->font();
    tituloFont.setPointSize(14);
    tituloFont.setBold(true);
    etiquetaTitulo->setFont(tituloFont);
    
    QFont metadataFont = etiquetaArtista->font();
    metadataFont.setPointSize(12);
    etiquetaArtista->setFont(metadataFont);
    etiquetaAlbum->setFont(metadataFont);
    etiquetaGenero->setFont(metadataFont);
    
    // Lista de reproducción
    listaReproduccion = new QListWidget(this);
    listaReproduccion->setMinimumWidth(300);
    listaReproduccion->setAlternatingRowColors(true);
    listaReproduccion->setDragDropMode(QAbstractItemView::InternalMove);
    
    // Selector de tema
    selectorTema = new QComboBox(this);
    selectorTema->addItems({"Apple Music", "Spotify", "Winamp"});
    
    // Visualizador
    visualizador = new QWidget(this);
    visualizador->setMinimumSize(200, 100);
    visualizador->setMaximumHeight(150);
    
    // Layout para el visualizador
    QVBoxLayout *layoutVisualizador = new QVBoxLayout(visualizador);
    layoutVisualizador->setContentsMargins(0, 0, 0, 0);
    visualizador->setLayout(layoutVisualizador);
}

void MainWindow::crearLayout() {
    // Layout principal
    layoutPrincipal = new QVBoxLayout;
    
    // Layout superior
    QHBoxLayout *layoutSuperior = new QHBoxLayout;
    
    // Panel izquierdo (visualizador y controles)
    QVBoxLayout *layoutIzquierdo = new QVBoxLayout;
    layoutIzquierdo->addWidget(visualizador);
    
    // Controles de reproducción
    QHBoxLayout *layoutControles = new QHBoxLayout;
    layoutControles->addWidget(botonReproducir);
    layoutControles->addWidget(botonPausar);
    layoutControles->addWidget(sliderProgreso);
    layoutIzquierdo->addLayout(layoutControles);
    
    // Control de volumen
    QHBoxLayout *layoutVolumen = new QHBoxLayout;
    layoutVolumen->addWidget(etiquetaVolumen);
    layoutVolumen->addWidget(sliderVolumen);
    layoutIzquierdo->addLayout(layoutVolumen);
    
    // Panel derecho (información y lista)
    QVBoxLayout *layoutDerecho = new QVBoxLayout;
    
    // Grupo de información
    QGroupBox *grupoInfo = new QGroupBox("Información de la Pista", this);
    QVBoxLayout *layoutInfo = new QVBoxLayout;
    layoutInfo->addWidget(etiquetaTitulo);
    layoutInfo->addWidget(etiquetaArtista);
    layoutInfo->addWidget(etiquetaAlbum);
    layoutInfo->addWidget(etiquetaGenero);
    layoutInfo->addWidget(etiquetaCalidad);
    grupoInfo->setLayout(layoutInfo);
    
    // Grupo de información técnica
    QGroupBox *grupoTecnico = new QGroupBox("Información Técnica", this);
    QGridLayout *layoutTecnico = new QGridLayout(grupoTecnico);
    layoutTecnico->addWidget(etiquetaSampleRate, 0, 0);
    layoutTecnico->addWidget(etiquetaChannels, 1, 0);
    layoutTecnico->addWidget(etiquetaBitrate, 2, 0);
    layoutTecnico->addWidget(etiquetaCodec, 3, 0);
    layoutTecnico->addWidget(etiquetaCodecProfile, 4, 0);
    layoutTecnico->addWidget(etiquetaEncoding, 5, 0);
    layoutTecnico->addWidget(etiquetaTagType, 6, 0);
    grupoTecnico->setLayout(layoutTecnico);
    
    // Lista de reproducción con título
    QGroupBox *grupoLista = new QGroupBox("Lista de Reproducción", this);
    QVBoxLayout *layoutLista = new QVBoxLayout;
    QHBoxLayout *layoutListaHeader = new QHBoxLayout;
    layoutListaHeader->addWidget(botonAbrir);
    layoutListaHeader->addWidget(selectorTema);
    layoutLista->addLayout(layoutListaHeader);
    layoutLista->addWidget(listaReproduccion);
    grupoLista->setLayout(layoutLista);
    
    layoutDerecho->addWidget(grupoInfo);
    layoutDerecho->addWidget(grupoTecnico);
    layoutDerecho->addWidget(grupoLista);
    
    // Combinar layouts
    layoutSuperior->addLayout(layoutIzquierdo, 1);
    layoutSuperior->addLayout(layoutDerecho, 1);
    
    layoutPrincipal->addLayout(layoutSuperior);
    
    // Widget central
    QWidget *widgetCentral = new QWidget;
    widgetCentral->setLayout(layoutPrincipal);
    setCentralWidget(widgetCentral);
}

void MainWindow::crearConexiones() {
    // Conexiones de botones
    connect(botonAbrir, &QPushButton::clicked, this, &MainWindow::abrirArchivo);
    connect(botonReproducir, &QPushButton::clicked, this, &MainWindow::reproducir);
    connect(botonPausar, &QPushButton::clicked, this, &MainWindow::pausar);
    
    // Conexiones de sliders
    connect(sliderVolumen, &QSlider::valueChanged, this, &MainWindow::cambiarVolumen);
    connect(sliderProgreso, &QSlider::sliderMoved, this, &MainWindow::buscarPosicion);
    
    // Conexiones del reproductor
    QMediaPlayer *player = reproductor->obtenerMediaPlayer();
    connect(player, &QMediaPlayer::positionChanged, this, &MainWindow::actualizarPosicion);
    connect(player, &QMediaPlayer::durationChanged, this, &MainWindow::actualizarDuracion);
    connect(player, &QMediaPlayer::mediaStatusChanged, this, &MainWindow::actualizarMetadatos);
    
    // Conexión del selector de tema
    connect(selectorTema, QOverload<int>::of(&QComboBox::currentIndexChanged),
            [this](int index) {
                aplicarTema(static_cast<Tema::TipoTema>(index));
            });
    
    // Conexión de la lista de reproducción
    connect(listaReproduccion, &QListWidget::itemDoubleClicked,
            [this](QListWidgetItem* item) {
                // Implementar reproducción desde lista
            });
}

void MainWindow::configurarBarraEstado() {
    // Crear widgets permanentes para la barra de estado
    estadoReproduccion = new QLabel("♪ Listo", this);
    estadoReproduccion->setObjectName("estadoReproduccion");
    estadoReproduccion->setMinimumWidth(300);
    estadoReproduccion->setMaximumWidth(500);
    estadoReproduccion->setTextFormat(Qt::RichText);
    
    estadoVolumen = new QLabel("♪ 100%", this);
    estadoVolumen->setObjectName("estadoVolumen");
    
    estadoDuracion = new QLabel("00:00 / 00:00", this);
    estadoDuracion->setObjectName("estadoDuracion");
    
    estadoCalidad = new QLabel("-", this);
    estadoCalidad->setObjectName("estadoCalidad");
    
    // Configurar la barra de estado
    barraEstado = new QStatusBar(this);
    barraEstado->addWidget(estadoReproduccion, 1);
    barraEstado->addPermanentWidget(estadoCalidad);
    barraEstado->addPermanentWidget(estadoDuracion);
    barraEstado->addPermanentWidget(estadoVolumen);
    
    setStatusBar(barraEstado);
}

void MainWindow::abrirArchivo() {
    QString archivo = QFileDialog::getOpenFileName(this, "Abrir Archivo de Audio",
        QDir::homePath(), "Archivos de Audio (*.mp3 *.wav *.ogg *.m4a)");
        
    if (!archivo.isEmpty()) {
        reproductor->cargarArchivo(archivo);
        estadoReproduccion->setText("Archivo cargado: " + QFileInfo(archivo).fileName());
        reproducir();
    }
}

void MainWindow::reproducir() {
    reproductor->reproducir();
    QString texto = estadoReproduccion->text();
    if (texto.startsWith("♪")) {
        texto = texto.mid(2);
    }
    estadoReproduccion->setText("▶ " + texto);
}

void MainWindow::pausar() {
    reproductor->pausar();
    QString texto = estadoReproduccion->text();
    if (texto.startsWith("▶")) {
        texto = texto.mid(2);
    }
    estadoReproduccion->setText("⏸ " + texto);
}

void MainWindow::cambiarVolumen(int volumen) {
    reproductor->obtenerAudioOutput()->setVolume(volumen / 100.0);
    etiquetaVolumen->setText(QString("Volumen: %1%").arg(volumen));
    estadoVolumen->setText(QString("♪ %1%").arg(volumen));
}

void MainWindow::buscarPosicion(int posicion) {
    reproductor->obtenerMediaPlayer()->setPosition(posicion);
    QTime tiempo = QTime::fromMSecsSinceStartOfDay(posicion);
    QTime duracion = QTime::fromMSecsSinceStartOfDay(reproductor->obtenerMediaPlayer()->duration());
    estadoDuracion->setText(QString("%1 / %2").arg(tiempo.toString("mm:ss"))
                                            .arg(duracion.toString("mm:ss")));
}

void MainWindow::actualizarMetadatos() {
    QMediaPlayer *player = reproductor->obtenerMediaPlayer();
    QMediaMetaData metaData = player->metaData();
    
    QString titulo = metaData.stringValue(QMediaMetaData::Title);
    QString artista = metaData.stringValue(QMediaMetaData::AlbumArtist);
    QString album = metaData.stringValue(QMediaMetaData::AlbumTitle);
    QString genero = metaData.stringValue(QMediaMetaData::Genre);
    
    // Obtener información del archivo
    QFileInfo fileInfo(player->source().toString());
    QString extension = fileInfo.suffix().toUpper();
    
    // Obtener bitrate
    qint64 bitrate = 0;
    QVariant bitrateVariant = metaData.value(QMediaMetaData::AudioBitRate);
    if (bitrateVariant.isValid()) {
        bitrate = bitrateVariant.toLongLong();
    }
    
    // Actualizar etiquetas principales
    if (!titulo.isEmpty()) {
        etiquetaTitulo->setText(titulo);
        QString estadoTexto = QString("♪ %1").arg(titulo);
        if (!artista.isEmpty() && artista != "Sin artista") {
            estadoTexto += QString(" - %1").arg(artista);
        }
        estadoReproduccion->setText(estadoTexto);
    } else {
        QString nombreArchivo = fileInfo.fileName();
        etiquetaTitulo->setText(nombreArchivo);
        estadoReproduccion->setText("♪ " + nombreArchivo);
    }
    
    // Actualizar metadatos básicos
    etiquetaArtista->setText(artista.isEmpty() ? "Sin artista" : artista);
    etiquetaAlbum->setText(album.isEmpty() ? "Sin álbum" : album);
    etiquetaGenero->setText(genero.isEmpty() ? "Sin género" : genero);
    
    // Inferir información técnica basada en el formato
    QString sampleRateStr;
    QString channelsStr;
    QString codecProfileStr;
    QString encodingStr;
    QString tagTypeStr;
    
    if (extension == "MP3") {
        sampleRateStr = "44100 Hz";
        channelsStr = "2";
        codecProfileStr = "MP3 CBR";
        encodingStr = "lossy";
        tagTypeStr = "id3v2.4|id3v1";
    } else if (extension == "WAV") {
        sampleRateStr = "44100 Hz";
        channelsStr = "2";
        codecProfileStr = "PCM";
        encodingStr = "lossless";
        tagTypeStr = "RIFF";
    } else if (extension == "FLAC") {
        sampleRateStr = "44100 Hz";
        channelsStr = "2";
        codecProfileStr = "FLAC";
        encodingStr = "lossless";
        tagTypeStr = "Vorbis";
    } else {
        sampleRateStr = "-";
        channelsStr = "-";
        codecProfileStr = "-";
        encodingStr = "-";
        tagTypeStr = "-";
    }
    
    // Actualizar etiquetas técnicas
    etiquetaSampleRate->setText(QString("Sample rate: %1").arg(sampleRateStr));
    etiquetaChannels->setText(QString("Canales: %1").arg(channelsStr));
    
    // Formatear bitrate
    QString bitrateStr;
    if (bitrate > 0) {
        if (bitrate >= 1000000) {
            double mbps = bitrate / 1000000.0;
            bitrateStr = QString("%1 Mbps").arg(mbps, 0, 'f', mbps < 10 ? 1 : 0);
        } else {
            bitrateStr = QString("%1 kbps").arg(bitrate / 1000);
        }
    } else {
        bitrateStr = "-";
    }
    etiquetaBitrate->setText("Bitrate: " + bitrateStr);
    
    // Actualizar códec y perfil
    etiquetaCodec->setText("Codec: " + extension);
    etiquetaCodecProfile->setText("Perfil: " + codecProfileStr);
    etiquetaEncoding->setText("Codificación: " + encodingStr);
    etiquetaTagType->setText("Tipo de etiqueta: " + tagTypeStr);
    
    // Actualizar calidad general
    QStringList calidadInfo;
    calidadInfo << extension;
    if (!bitrateStr.isEmpty() && bitrateStr != "-") {
        calidadInfo << bitrateStr;
    }
    QString calidadTexto = calidadInfo.join(" • ");
    
    etiquetaCalidad->setText("Calidad: " + calidadTexto);
    estadoCalidad->setText(calidadTexto);
    
    // Actualizar tooltip
    if (!titulo.isEmpty()) {
        QStringList tooltipInfo;
        tooltipInfo << titulo;
        
        if (!artista.isEmpty() && artista != "Sin artista") {
            tooltipInfo << QString("Artista: %1").arg(artista);
        }
        if (!album.isEmpty() && album != "Sin álbum") {
            tooltipInfo << QString("Álbum: %1").arg(album);
        }
        if (!genero.isEmpty() && genero != "Sin género") {
            tooltipInfo << QString("Género: %1").arg(genero);
        }
        
        // Agregar información técnica al tooltip
        tooltipInfo << QString("Sample rate: %1").arg(sampleRateStr);
        tooltipInfo << QString("Canales: %1").arg(channelsStr);
        if (!bitrateStr.isEmpty() && bitrateStr != "-") {
            tooltipInfo << QString("Bitrate: %1").arg(bitrateStr);
        }
        tooltipInfo << QString("Codec: %1").arg(extension);
        tooltipInfo << QString("Perfil: %1").arg(codecProfileStr);
        tooltipInfo << QString("Codificación: %1").arg(encodingStr);
        
        QString tooltipText = tooltipInfo.join("\n");
        etiquetaTitulo->setToolTip(tooltipText);
        estadoReproduccion->setToolTip(tooltipText);
    }
}

void MainWindow::actualizarEstado(const QString& mensaje, int timeout) {
    if (timeout > 0) {
        barraEstado->showMessage(mensaje, timeout);
    } else {
        barraEstado->showMessage(mensaje);
    }
}

void MainWindow::actualizarPosicion(qint64 posicion) {
    if (!sliderProgreso->isSliderDown()) {
        sliderProgreso->setValue(posicion);
    }
    
    QTime tiempoActual = QTime::fromMSecsSinceStartOfDay(posicion);
    QTime duracionTotal = QTime::fromMSecsSinceStartOfDay(reproductor->obtenerMediaPlayer()->duration());
    estadoDuracion->setText(QString("%1 / %2").arg(tiempoActual.toString("mm:ss"))
                                            .arg(duracionTotal.toString("mm:ss")));
}

void MainWindow::actualizarDuracion(qint64 duracion) {
    sliderProgreso->setMaximum(duracion);
    QTime tiempoTotal = QTime::fromMSecsSinceStartOfDay(duracion);
    estadoDuracion->setText(QString("00:00 / %1").arg(tiempoTotal.toString("mm:ss")));
}

void MainWindow::aplicarTema(Tema::TipoTema tipo) {
    QString rutaEstilo;
    switch (tipo) {
        case Tema::AppleMusic:
            rutaEstilo = ":/styles/apple_music.qss";
            break;
        case Tema::Spotify:
            rutaEstilo = ":/styles/spotify.qss";
            break;
        case Tema::Winamp:
            rutaEstilo = ":/styles/winamp.qss";
            break;
        default:
            rutaEstilo = ":/styles/apple_music.qss";
    }

    QFile archivo(rutaEstilo);
    archivo.open(QFile::ReadOnly | QFile::Text);
    QTextStream stream(&archivo);
    setStyleSheet(stream.readAll());
    
    // Configurar fuentes específicas del tema
    Tema::EstiloTema tema = Tema::obtenerTema(tipo);
    etiquetaTitulo->setFont(tema.fuenteTitulo);
    etiquetaArtista->setFont(tema.fuenteNormal);
    etiquetaAlbum->setFont(tema.fuenteNormal);
    etiquetaGenero->setFont(tema.fuenteNormal);
    etiquetaCalidad->setFont(tema.fuenteNormal);
    
    // Configurar colores específicos
    QPalette paleta = this->palette();
    paleta.setColor(QPalette::Window, tema.colorFondo);
    paleta.setColor(QPalette::WindowText, tema.colorTexto);
    setPalette(paleta);
}

MainWindow::~MainWindow() {
    delete reproductor;
}
