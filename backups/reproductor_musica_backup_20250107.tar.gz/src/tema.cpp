#include "tema.h"

Tema::EstiloTema Tema::crearTemaAppleMusic() {
    EstiloTema tema;
    
    // Colores inspirados en Apple Music
    tema.colorFondo = QColor("#ffffff");
    tema.colorPrimario = QColor("#fc3c44");
    tema.colorSecundario = QColor("#f2f2f2");
    tema.colorTexto = QColor("#000000");
    tema.colorAcento = QColor("#fc3c44");
    
    // Fuentes
    tema.fuenteTitulo = QFont("SF Pro Display", 24, QFont::Medium);
    tema.fuenteNormal = QFont("SF Pro Text", 13);
    
    // Radios
    tema.radioBordes = 8;
    
    // Estilos
    tema.estiloBotonPrimario = "QPushButton {"
                              "    background-color: #fc3c44;"
                              "    color: white;"
                              "    border-radius: 8px;"
                              "    padding: 8px 16px;"
                              "    font-weight: 500;"
                              "}"
                              "QPushButton:hover {"
                              "    background-color: #fd484f;"
                              "}";
                              
    tema.estiloSlider = "QSlider::groove:horizontal {"
                        "    border: 1px solid #e1e1e1;"
                        "    height: 4px;"
                        "    background: #f2f2f2;"
                        "    margin: 2px 0;"
                        "    border-radius: 2px;"
                        "}"
                        "QSlider::handle:horizontal {"
                        "    background: #fc3c44;"
                        "    border: none;"
                        "    width: 18px;"
                        "    height: 18px;"
                        "    margin: -8px 0;"
                        "    border-radius: 9px;"
                        "}";
    
    return tema;
}

Tema::EstiloTema Tema::crearTemaSpotify() {
    EstiloTema tema;
    
    // Colores inspirados en Spotify
    tema.colorFondo = QColor("#121212");
    tema.colorPrimario = QColor("#1db954");
    tema.colorSecundario = QColor("#282828");
    tema.colorTexto = QColor("#ffffff");
    tema.colorAcento = QColor("#1db954");
    
    // Fuentes
    tema.fuenteTitulo = QFont("Gotham", 24, QFont::Bold);
    tema.fuenteNormal = QFont("Gotham", 13);
    
    // Radios
    tema.radioBordes = 4;
    
    // Estilos
    tema.estiloBotonPrimario = "QPushButton {"
                              "    background-color: #1db954;"
                              "    color: white;"
                              "    border-radius: 4px;"
                              "    padding: 8px 16px;"
                              "    font-weight: bold;"
                              "}"
                              "QPushButton:hover {"
                              "    background-color: #1ed760;"
                              "}";
                              
    tema.estiloSlider = "QSlider::groove:horizontal {"
                        "    border: none;"
                        "    height: 4px;"
                        "    background: #535353;"
                        "    margin: 2px 0;"
                        "}"
                        "QSlider::handle:horizontal {"
                        "    background: #1db954;"
                        "    border: none;"
                        "    width: 12px;"
                        "    height: 12px;"
                        "    margin: -4px 0;"
                        "    border-radius: 6px;"
                        "}";
    
    return tema;
}

Tema::EstiloTema Tema::crearTemaWinamp() {
    EstiloTema tema;
    
    // Colores inspirados en Winamp Classic
    tema.colorFondo = QColor("#000000");
    tema.colorPrimario = QColor("#00FF00");
    tema.colorSecundario = QColor("#333333");
    tema.colorTexto = QColor("#00FF00");
    tema.colorAcento = QColor("#00FF00");
    
    // Fuentes
    tema.fuenteTitulo = QFont("Digital-7", 24);
    tema.fuenteNormal = QFont("MS Sans Serif", 12);
    
    // Radios
    tema.radioBordes = 0;
    
    // Estilos
    tema.estiloBotonPrimario = "QPushButton {"
                              "    background-color: #333333;"
                              "    color: #00FF00;"
                              "    border: 1px solid #00FF00;"
                              "    padding: 4px 8px;"
                              "}"
                              "QPushButton:hover {"
                              "    background-color: #00FF00;"
                              "    color: black;"
                              "}";
                              
    tema.estiloSlider = "QSlider::groove:horizontal {"
                        "    border: 1px solid #00FF00;"
                        "    height: 6px;"
                        "    background: black;"
                        "}"
                        "QSlider::handle:horizontal {"
                        "    background: #00FF00;"
                        "    border: 1px solid #00FF00;"
                        "    width: 18px;"
                        "    height: 18px;"
                        "    margin: -6px 0;"
                        "}";
    
    return tema;
}

Tema::EstiloTema Tema::obtenerTema(TipoTema tipo) {
    switch (tipo) {
        case AppleMusic:
            return crearTemaAppleMusic();
        case Spotify:
            return crearTemaSpotify();
        case Winamp:
            return crearTemaWinamp();
        default:
            return crearTemaAppleMusic();
    }
}

QString Tema::obtenerHojaEstilo(TipoTema tipo) {
    EstiloTema tema = obtenerTema(tipo);
    return QString("QMainWindow { background-color: %1; color: %2; }")
           .arg(tema.colorFondo.name())
           .arg(tema.colorTexto.name());
}
