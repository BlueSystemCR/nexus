#ifndef REPRODUCTOR_H
#define REPRODUCTOR_H

#include <QObject>
#include <QMediaPlayer>
#include <QAudioOutput>

class Reproductor : public QObject {
    Q_OBJECT

public:
    explicit Reproductor(QObject *parent = nullptr);
    ~Reproductor();

    void cargarArchivo(const QString &ruta);
    void reproducir();
    void pausar();
    QMediaPlayer* obtenerMediaPlayer() { return reproductor; }
    QAudioOutput* obtenerAudioOutput() { return salidaAudio; }

private:
    QMediaPlayer *reproductor;
    QAudioOutput *salidaAudio;
};

#endif // REPRODUCTOR_H
