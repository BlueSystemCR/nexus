#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QSlider>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QListWidget>
#include <QComboBox>
#include <QStatusBar>
#include <QFileDialog>
#include <QDir>
#include "reproductor.h"
#include "tema.h"

class MainWindow : public QMainWindow {
    Q_OBJECT
    
public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    
private slots:
    void abrirArchivo();
    void reproducir();
    void pausar();
    void cambiarVolumen(int volumen);
    void buscarPosicion(int posicion);
    void actualizarMetadatos();
    void actualizarPosicion(qint64 posicion);
    void actualizarDuracion(qint64 duracion);
    void actualizarEstado(const QString& mensaje, int timeout = 0);
    
private:
    void crearWidgets();
    void crearLayout();
    void crearConexiones();
    void aplicarTema(Tema::TipoTema tipo);
    void configurarBarraEstado();
    
    Reproductor *reproductor;
    
    // Widgets de control
    QPushButton *botonAbrir;
    QPushButton *botonReproducir;
    QPushButton *botonPausar;
    QSlider *sliderProgreso;
    QSlider *sliderVolumen;
    QLabel *etiquetaVolumen;
    QListWidget *listaReproduccion;
    QVBoxLayout *layoutPrincipal;
    QHBoxLayout *layoutControles;
    QVBoxLayout *layoutDerecho;
    QWidget *visualizador;
    QLabel *etiquetaVisualizador;
    QComboBox *selectorTema;
    
    // Barra de estado
    QStatusBar *barraEstado;
    QLabel *estadoReproduccion;
    QLabel *estadoVolumen;
    QLabel *estadoDuracion;
    QLabel *estadoCalidad;
    
    // Widgets para metadatos
    QLabel *etiquetaTitulo;
    QLabel *etiquetaArtista;
    QLabel *etiquetaAlbum;
    QLabel *etiquetaGenero;
    QLabel *etiquetaCalidad;
    
    // Etiquetas de información técnica
    QLabel *etiquetaSampleRate;
    QLabel *etiquetaChannels;
    QLabel *etiquetaBitrate;
    QLabel *etiquetaCodec;
    QLabel *etiquetaCodecProfile;
    QLabel *etiquetaEncoding;
    QLabel *etiquetaTagType;

};

#endif // MAINWINDOW_H
