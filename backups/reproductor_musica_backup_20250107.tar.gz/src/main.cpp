#include <QApplication>
#include "mainwindow.h"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    
    MainWindow ventanaPrincipal;
    ventanaPrincipal.setWindowTitle("Reproductor de Música");
    ventanaPrincipal.resize(800, 600);
    ventanaPrincipal.show();
    
    return app.exec();
}
