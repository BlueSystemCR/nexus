#include "reproductor.h"
#include <QUrl>

Reproductor::Reproductor(QObject *parent)
    : QObject(parent)
{
    reproductor = new QMediaPlayer(this);
    salidaAudio = new QAudioOutput(this);
    reproductor->setAudioOutput(salidaAudio);
}

Reproductor::~Reproductor()
{
    delete reproductor;
    delete salidaAudio;
}

void Reproductor::cargarArchivo(const QString &ruta)
{
    reproductor->setSource(QUrl::fromLocalFile(ruta));
}

void Reproductor::reproducir()
{
    reproductor->play();
}

void Reproductor::pausar()
{
    reproductor->pause();
}
